﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LinqAssignmetn
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        // on form load populate the combo box
        private void Form1_Load(object sender, EventArgs e)
        {
           
            foreach(Customers i in CustomerDb.GetCustomerId()){
                cmbCustId.Items.Add(i.CustomerId.ToString());
            }
          
        }
        //on list index change fill the grid view
        private void cmbCustId_SelectedIndexChanged(object sender, EventArgs e)
        {
            dataGridView1.DataSource = CustomerDb.GetCustomer(cmbCustId.Text);
        }
    }
}
