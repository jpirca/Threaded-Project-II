﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LinqAssignmetn
{
    //static class contains Lists items for filling combo box and grid view
    public static class CustomerDb
    {
        public static List<Customers> GetCustomer(string custId)
        {
            List<Customers> cust = new List<Customers>();
            //define a datacontext for northwind
           NorthwindDataContext db = new NorthwindDataContext();

            
            //Join linq query as equi join
            var query = from c in db.Customers
                        join d in db.Orders
                        on c.CustomerID equals d.CustomerID
                        where c.CustomerID==custId
                        select new
                        {
                            c.CompanyName,
                            c.ContactName,
                            c.ContactTitle,
                            d.ShipName,
                            d.ShipAddress,
                            d.ShippedDate
                        };


            Customers cobj;
            //fill the list
            foreach (var q in query)
            {
                cobj = new Customers();
                cobj.CompanyName = q.CompanyName;
                cobj.ContactName = q.ContactName;
                cobj.ContactTitle = q.ContactTitle;
                cobj.ShipAddress = q.ShipAddress;
                cobj.ShipName = q.ShipName;
                cobj.ShippedDate =Convert.ToString(q.ShippedDate);
                cust.Add(cobj);

               
            }
            //return the list
            return cust;
          
        }
        //list to fill the combo box
        public static List<Customers> GetCustomerId()
        {
            List<Customers> GetCustId = new List<Customers>();
            //make a database context for northwid database
            NorthwindDataContext db = new NorthwindDataContext();
            //Linq query to access customers id and fill in a list
            var query = (from c in db.Customers
                        
                        select new {c.CustomerID }).ToList();
            Customers CustIdObj;
            foreach(var q in query)
            {
                CustIdObj = new Customers();
                CustIdObj.CustomerId =Convert.ToString(q.CustomerID);
                //fill the list
                GetCustId.Add(CustIdObj);
            }
            //return the list
            return GetCustId;
        }


    }
    }

