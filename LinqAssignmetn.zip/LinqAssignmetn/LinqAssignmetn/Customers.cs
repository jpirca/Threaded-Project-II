﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LinqAssignmetn
{
    //Customers Class, define all properties, which need to be displayed 
    public class Customers
    {
        public Customers() { }
        // public string CustomerID { get; set; }
        public string CustomerId;
        public string CompanyName { get; set; }

        public string ContactName{ get; set; }

        public string ContactTitle { get; set; }
        public string ShipName { get; set; }
        public string ShipAddress { get; set; }
        public string ShippedDate{ get; set; }

       // c.CompanyName,c.ContactName,c.ContactTitle,d.ShipName, d.ShipAddress,d.ShippedDate


    }
}
